/**
 * app.js
 * ---------------------------------------------------------------------------
 * Application bootstrap. Runs once when the page loads:
 *   1. Applies the theme colors/fonts from data/app_config.js as CSS
 *      variables (so editing that one file re-themes the whole app).
 *   2. Sets the initial language.
 *   3. Connects Navigation (which screen is active) to Render (how it
 *      looks), then renders the first screen.
 * ---------------------------------------------------------------------------
 */

(function () {
  function applyTheme() {
    const root = document.documentElement;
    const theme = window.AppConfig.theme;
    const fonts = window.AppConfig.fonts;

    Object.keys(theme).forEach(function (key) {
      // Converts "colorPrimary" -> "--color-primary", "radiusSmall" -> "--radius-small"
      const cssVarName =
        "--" + key.replace(/([A-Z])/g, "-$1").toLowerCase();
      root.style.setProperty(cssVarName, theme[key]);
    });

    root.style.setProperty("--font-primary", fonts.primary);
    root.style.setProperty("--font-heading", fonts.heading);
  }

  function setDocumentTitle() {
    document.title = Language.pick(window.AppConfig.appName);
  }

  function init() {
    applyTheme();
    Language.setLanguage(window.AppConfig.defaultLanguage || "ar");
    setDocumentTitle();

    Render.renderTopBar();

    Navigation.onChange(function (screenName) {
      Render.renderScreen(screenName);
      setDocumentTitle();
    });

    // Draw the first screen.
    Render.renderScreen(Navigation.getCurrentScreen());
  }

  document.addEventListener("DOMContentLoaded", init);
})();
