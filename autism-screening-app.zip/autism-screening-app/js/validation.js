/**
 * validation.js
 * ---------------------------------------------------------------------------
 * Validation rules used before allowing the user to move to the next step.
 * Error messages come from data/translations.js so they are always shown
 * in the currently selected language.
 * ---------------------------------------------------------------------------
 */

window.Validation = (function () {
  /**
   * Validates the person info form.
   * Returns { valid: boolean, errors: { field: message } }
   */
  function validatePersonInfo(personInfo) {
    const errors = {};

    const name = (personInfo.name || "").trim();
    if (name.length === 0) {
      errors.name = Language.t("personInfo.errors.nameRequired");
    }

    const rawAge = (personInfo.age || "").toString().trim();
    if (rawAge.length === 0) {
      errors.age = Language.t("personInfo.errors.ageRequired");
    } else {
      const ageNumber = Number(rawAge);
      if (!Number.isInteger(ageNumber) || Number.isNaN(ageNumber)) {
        errors.age = Language.t("personInfo.errors.ageInvalid");
      } else if (ageNumber < 0) {
        errors.age = Language.t("personInfo.errors.ageNegative");
      }
    }

    if (!personInfo.gender) {
      errors.gender = Language.t("personInfo.errors.genderRequired");
    }

    return {
      valid: Object.keys(errors).length === 0,
      errors: errors
    };
  }

  /** True if the given question has an answer selected in State. */
  function isQuestionAnswered(questionId) {
    return Boolean(State.getAnswer(questionId));
  }

  return {
    validatePersonInfo: validatePersonInfo,
    isQuestionAnswered: isQuestionAnswered
  };
})();
