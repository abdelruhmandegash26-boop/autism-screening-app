/**
 * state.js
 * ---------------------------------------------------------------------------
 * A single, simple in-memory state object for the current assessment
 * session. Nothing here touches the DOM or localStorage directly — this is
 * pure data that the render/navigation code reads from and writes to.
 * ---------------------------------------------------------------------------
 */

window.State = (function () {
  let data = createEmptyState();

  function createEmptyState() {
    return {
      userType: null, // "parent" | "specialist" | "audio_parent"
      personInfo: {
        name: "",
        age: "",
        gender: "",
        date: new Date().toISOString().slice(0, 10),
        notes: ""
      },
      answers: {}, // { questionId: answerId }
      currentQuestionIndex: 0,
      score: 0,
      resultKey: null, // "low" | "moderate" | "high"
      savedRecordId: null
    };
  }

  function reset() {
    data = createEmptyState();
  }

  function get() {
    return data;
  }

  function setUserType(userType) {
    data.userType = userType;
  }

  function setPersonInfoField(field, value) {
    data.personInfo[field] = value;
  }

  function setAnswer(questionId, answerId) {
    data.answers[questionId] = answerId;
  }

  function getAnswer(questionId) {
    return data.answers[questionId];
  }

  function getAnsweredCount() {
    return Object.keys(data.answers).length;
  }

  function setCurrentQuestionIndex(index) {
    data.currentQuestionIndex = index;
  }

  function setScoreResult(score, resultKey) {
    data.score = score;
    data.resultKey = resultKey;
  }

  function setSavedRecordId(id) {
    data.savedRecordId = id;
  }

  return {
    reset: reset,
    get: get,
    setUserType: setUserType,
    setPersonInfoField: setPersonInfoField,
    setAnswer: setAnswer,
    getAnswer: getAnswer,
    getAnsweredCount: getAnsweredCount,
    setCurrentQuestionIndex: setCurrentQuestionIndex,
    setScoreResult: setScoreResult,
    setSavedRecordId: setSavedRecordId
  };
})();
