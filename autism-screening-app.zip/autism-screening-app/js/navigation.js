/**
 * navigation.js
 * ---------------------------------------------------------------------------
 * Controls WHICH screen is shown, in what order, without knowing anything
 * about how each screen is actually drawn (that's render.js's job).
 *
 * The screen order comes from data/app_config.js -> screenOrder, so you can
 * reorder the flow there without touching this file.
 * ---------------------------------------------------------------------------
 */

window.Navigation = (function () {
  const screens = window.AppConfig.screenOrder;
  let currentIndex = 0;
  let onChangeCallback = null;

  /** Registers the function to call whenever the active screen changes. */
  function onChange(callback) {
    onChangeCallback = callback;
  }

  function getCurrentScreen() {
    return screens[currentIndex];
  }

  function render() {
    if (onChangeCallback) {
      onChangeCallback(getCurrentScreen());
    }
  }

  /**
   * Moves to the next screen in the order, but only if `validateFn`
   * (if given) returns true. Returns true if navigation happened.
   */
  function goNext(validateFn) {
    if (typeof validateFn === "function" && !validateFn()) {
      return false;
    }
    if (currentIndex < screens.length - 1) {
      currentIndex++;
      render();
      return true;
    }
    return false;
  }

  function goBack() {
    if (currentIndex > 0) {
      currentIndex--;
      render();
      return true;
    }
    return false;
  }

  /** Jumps directly to a named screen (must exist in screenOrder). */
  function goToScreen(screenName) {
    const index = screens.indexOf(screenName);
    if (index === -1) {
      console.error("[Navigation] Unknown screen:", screenName);
      return false;
    }
    currentIndex = index;
    render();
    return true;
  }

  function reset() {
    currentIndex = 0;
    render();
  }

  return {
    onChange: onChange,
    getCurrentScreen: getCurrentScreen,
    goNext: goNext,
    goBack: goBack,
    goToScreen: goToScreen,
    reset: reset
  };
})();
