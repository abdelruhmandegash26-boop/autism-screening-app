/**
 * audio.js
 * ---------------------------------------------------------------------------
 * Plays local audio files (see data/audio_parent_questions.js for paths).
 *
 * If a file is missing or fails to load, this module falls back to the
 * browser's BUILT-IN speech synthesis (window.speechSynthesis), which runs
 * entirely on-device and requires no internet connection or online TTS
 * service. If speech synthesis is also unavailable, it fails silently.
 *
 * To replace an audio file: just replace the .mp3 file on disk at the path
 * referenced in the data file — nothing here needs to change.
 * ---------------------------------------------------------------------------
 */

window.AppAudio = (function () {
  let currentAudioElement = null;

  function stop() {
    if (currentAudioElement) {
      currentAudioElement.pause();
      currentAudioElement.currentTime = 0;
      currentAudioElement = null;
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
  }

  /**
   * Plays a local audio file. Falls back to on-device speech synthesis of
   * `fallbackText` (in `lang`, "ar" or "en") if the file can't be played.
   */
  function play(filePath, fallbackText, lang) {
    stop();

    if (!filePath) {
      speak(fallbackText, lang);
      return;
    }

    const audioElement = new window.Audio(filePath);
    currentAudioElement = audioElement;

    audioElement.addEventListener("error", function () {
      speak(fallbackText, lang);
    });

    // Attempt playback; if the browser blocks it or the file is missing,
    // fall back to speech synthesis instead of failing silently.
    const playPromise = audioElement.play();
    if (playPromise && typeof playPromise.catch === "function") {
      playPromise.catch(function () {
        speak(fallbackText, lang);
      });
    }
  }

  /** On-device speech synthesis fallback. Never contacts an online service. */
  function speak(text, lang) {
    if (!text || !window.speechSynthesis) return;

    const utterance = new window.SpeechSynthesisUtterance(text);
    utterance.lang = lang === "ar" ? "ar-SA" : "en-US";
    window.speechSynthesis.speak(utterance);
  }

  return {
    play: play,
    speak: speak,
    stop: stop
  };
})();
