/**
 * questions.js
 * ---------------------------------------------------------------------------
 * Bridges the raw data files (data/parent_questions.js,
 * data/specialist_questions.js, data/audio_parent_questions.js) with the UI.
 *
 * This is the ONLY place that knows which data file corresponds to which
 * user type. If you add a new user type + question bank, register it in the
 * "banks" map below.
 * ---------------------------------------------------------------------------
 */

window.Questions = (function () {
  const banks = {
    parent: window.ParentQuestions,
    specialist: window.SpecialistQuestions,
    audio_parent: window.AudioParentQuestions
  };

  function getBank(userType) {
    const bank = banks[userType];
    if (!bank) {
      console.error("[Questions] Unknown user type:", userType);
    }
    return bank;
  }

  /**
   * Returns a flat array of question objects, each normalized to:
   *   { id, text, answers, icon, audio, categoryId, categoryTitle }
   * regardless of which bank it came from.
   */
  function getFlatQuestions(userType) {
    const bank = getBank(userType);
    if (!bank) return [];

    return bank.questions.map(function (question) {
      const category =
        question.categoryId && bank.categories
          ? bank.categories.find(function (c) {
              return c.id === question.categoryId;
            })
          : null;

      return {
        id: question.id,
        text: question.text,
        icon: question.icon || null,
        audio: question.audio || null,
        answers: question.answers || bank.defaultAnswers,
        categoryId: question.categoryId || null,
        categoryTitle: category ? category.title : null
      };
    });
  }

  function getTotalQuestions(userType) {
    return getFlatQuestions(userType).length;
  }

  function getQuestionByIndex(userType, index) {
    const list = getFlatQuestions(userType);
    return list[index] || null;
  }

  function getBankTitle(userType) {
    const bank = getBank(userType);
    return bank ? bank.title : { ar: "", en: "" };
  }

  return {
    getFlatQuestions: getFlatQuestions,
    getTotalQuestions: getTotalQuestions,
    getQuestionByIndex: getQuestionByIndex,
    getBankTitle: getBankTitle
  };
})();
