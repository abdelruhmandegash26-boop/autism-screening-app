/**
 * render.js
 * ---------------------------------------------------------------------------
 * Builds the HTML for each screen and attaches its event listeners.
 *
 * This file only deals with UI drawing. It reads/writes State through the
 * State module, and asks Navigation to move between screens — it does not
 * contain business rules (those live in validation.js / scoring.js).
 * ---------------------------------------------------------------------------
 */

window.Render = (function () {
  const screenContainer = document.getElementById("screen-container");

  function t(key, params) {
    return Language.t(key, params);
  }

  function pick(bilingual) {
    return Language.pick(bilingual);
  }

  function setHTML(html) {
    screenContainer.innerHTML = html;
    screenContainer.scrollTop = 0;
  }

  function escapeHTML(value) {
    const div = document.createElement("div");
    div.textContent = value == null ? "" : String(value);
    return div.innerHTML;
  }

  // -------------------------------------------------------------------
  // TOP BAR
  // -------------------------------------------------------------------
  function renderTopBar() {
    const bar = document.getElementById("top-bar");
    const lang = Language.getCurrentLanguage();
    bar.innerHTML =
      '<div class="top-bar-inner">' +
      '<div class="brand">' +
      '<img src="assets/images/logo.svg" alt="" class="brand-logo" />' +
      '<span class="brand-name">' +
      escapeHTML(pick(window.AppConfig.appName)) +
      "</span>" +
      "</div>" +
      '<div class="lang-toggle" role="group" aria-label="Language">' +
      '<button type="button" class="lang-btn' +
      (lang === "ar" ? " active" : "") +
      '" data-lang="ar">العربية</button>' +
      '<button type="button" class="lang-btn' +
      (lang === "en" ? " active" : "") +
      '" data-lang="en">English</button>' +
      "</div>" +
      "</div>";

    bar.querySelectorAll(".lang-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        Language.setLanguage(btn.getAttribute("data-lang"));
        renderTopBar();
        renderScreen(Navigation.getCurrentScreen());
      });
    });
  }

  // -------------------------------------------------------------------
  // SCREEN DISPATCH
  // -------------------------------------------------------------------
  function renderScreen(screenName) {
    const renderers = {
      welcome: renderWelcome,
      userType: renderUserType,
      personInfo: renderPersonInfo,
      instructions: renderInstructions,
      questions: renderQuestions,
      review: renderReview,
      result: renderResult,
      success: renderSuccess
    };

    const fn = renderers[screenName];
    if (fn) {
      fn();
    } else {
      console.error("[Render] No renderer for screen:", screenName);
    }
  }

  // -------------------------------------------------------------------
  // WELCOME
  // -------------------------------------------------------------------
  function renderWelcome() {
    const recordsButton = window.AppConfig.enableRecordsScreen
      ? '<button type="button" class="btn btn-ghost" id="btn-view-records">' +
        escapeHTML(t("welcome.viewRecords")) +
        "</button>"
      : "";

    setHTML(
      '<section class="screen screen-welcome">' +
        '<div class="welcome-card">' +
        '<img src="assets/images/logo.svg" alt="" class="welcome-logo" />' +
        '<h1 class="welcome-title">' +
        escapeHTML(pick(window.AppConfig.appName)) +
        "</h1>" +
        '<p class="welcome-subtitle">' +
        escapeHTML(t("welcome.subtitle")) +
        "</p>" +
        '<p class="demo-notice">' +
        escapeHTML(t("welcome.demoNotice")) +
        "</p>" +
        '<div class="welcome-actions">' +
        '<button type="button" class="btn btn-primary btn-large" id="btn-start">' +
        escapeHTML(t("welcome.start")) +
        "</button>" +
        recordsButton +
        "</div>" +
        '<p class="version-tag">' +
        escapeHTML(window.AppConfig.version) +
        "</p>" +
        "</div>" +
        "</section>"
    );

    document.getElementById("btn-start").addEventListener("click", function () {
      Navigation.goNext();
    });

    const recordsBtn = document.getElementById("btn-view-records");
    if (recordsBtn) {
      recordsBtn.addEventListener("click", function () {
        renderRecords();
      });
    }
  }

  // -------------------------------------------------------------------
  // USER TYPE SELECTION
  // -------------------------------------------------------------------
  function renderUserType() {
    const options = [
      {
        type: "parent",
        icon: "👪",
        titleKey: "userType.parent.title",
        subtitleKey: "userType.parent.subtitle",
        descKey: "userType.parent.description"
      },
      {
        type: "specialist",
        icon: "🩺",
        titleKey: "userType.specialist.title",
        subtitleKey: "userType.specialist.subtitle",
        descKey: "userType.specialist.description"
      },
      {
        type: "audio_parent",
        icon: "🔊",
        titleKey: "userType.audio.title",
        subtitleKey: "userType.audio.subtitle",
        descKey: "userType.audio.description"
      }
    ];

    const selected = State.get().userType;

    const cardsHTML = options
      .map(function (option) {
        const isSelected = selected === option.type;
        return (
          '<button type="button" class="type-card' +
          (isSelected ? " selected" : "") +
          '" data-type="' +
          option.type +
          '">' +
          '<span class="type-icon" aria-hidden="true">' +
          option.icon +
          "</span>" +
          '<span class="type-title">' +
          escapeHTML(t(option.titleKey)) +
          "</span>" +
          '<span class="type-subtitle">' +
          escapeHTML(t(option.subtitleKey)) +
          "</span>" +
          '<span class="type-description">' +
          escapeHTML(t(option.descKey)) +
          "</span>" +
          '<span class="type-select-tag">' +
          escapeHTML(isSelected ? t("userType.selected") : t("userType.select")) +
          "</span>" +
          "</button>"
        );
      })
      .join("");

    setHTML(
      '<section class="screen screen-user-type">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("userType.title")) +
        "</h1>" +
        '<p class="screen-subtitle">' +
        escapeHTML(t("userType.subtitle")) +
        "</p>" +
        '<div class="type-grid">' +
        cardsHTML +
        "</div>" +
        renderFooterNav({ nextDisabled: !selected }) +
        "</section>"
    );

    screenContainer.querySelectorAll(".type-card").forEach(function (card) {
      card.addEventListener("click", function () {
        State.setUserType(card.getAttribute("data-type"));
        renderUserType();
      });
    });

    attachFooterNav({
      onNext: function () {
        return Boolean(State.get().userType);
      },
      onBack: function () {
        Navigation.goBack();
      }
    });
  }

  // -------------------------------------------------------------------
  // PERSON INFO
  // -------------------------------------------------------------------
  function renderPersonInfo(errors) {
    errors = errors || {};
    const info = State.get().personInfo;

    setHTML(
      '<section class="screen screen-person-info">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("personInfo.title")) +
        "</h1>" +
        '<p class="screen-subtitle">' +
        escapeHTML(t("personInfo.subtitle")) +
        "</p>" +
        '<form class="form-grid" id="person-info-form" novalidate>' +
        formField(
          "name",
          t("personInfo.name"),
          '<input type="text" id="field-name" class="text-input" value="' +
            escapeHTML(info.name) +
            '" placeholder="' +
            escapeHTML(t("personInfo.namePlaceholder")) +
            '" />',
          errors.name
        ) +
        formField(
          "age",
          t("personInfo.age"),
          '<input type="number" min="0" step="1" id="field-age" class="text-input" value="' +
            escapeHTML(info.age) +
            '" placeholder="' +
            escapeHTML(t("personInfo.agePlaceholder")) +
            '" />',
          errors.age
        ) +
        formField(
          "gender",
          t("personInfo.gender"),
          '<div class="gender-options">' +
            genderOption("male", t("personInfo.genderMale"), info.gender) +
            genderOption("female", t("personInfo.genderFemale"), info.gender) +
            "</div>",
          errors.gender
        ) +
        formField(
          "date",
          t("personInfo.date"),
          '<input type="date" id="field-date" class="text-input" value="' +
            escapeHTML(info.date) +
            '" />'
        ) +
        formField(
          "notes",
          t("personInfo.notes"),
          '<textarea id="field-notes" class="text-input textarea-input" placeholder="' +
            escapeHTML(t("personInfo.notesPlaceholder")) +
            '">' +
            escapeHTML(info.notes) +
            "</textarea>"
        ) +
        "</form>" +
        renderFooterNav({}) +
        "</section>"
    );

    document.getElementById("field-name").addEventListener("input", function (e) {
      State.setPersonInfoField("name", e.target.value);
    });
    document.getElementById("field-age").addEventListener("input", function (e) {
      State.setPersonInfoField("age", e.target.value);
    });
    document.getElementById("field-date").addEventListener("input", function (e) {
      State.setPersonInfoField("date", e.target.value);
    });
    document.getElementById("field-notes").addEventListener("input", function (e) {
      State.setPersonInfoField("notes", e.target.value);
    });
    screenContainer.querySelectorAll(".gender-option-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        State.setPersonInfoField("gender", btn.getAttribute("data-gender"));
        renderPersonInfo();
      });
    });

    attachFooterNav({
      onNext: function () {
        const result = Validation.validatePersonInfo(State.get().personInfo);
        if (!result.valid) {
          renderPersonInfo(result.errors);
          return false;
        }
        return true;
      },
      onBack: function () {
        Navigation.goBack();
      }
    });
  }

  function genderOption(value, label, selectedValue) {
    return (
      '<button type="button" class="gender-option-btn' +
      (selectedValue === value ? " selected" : "") +
      '" data-gender="' +
      value +
      '">' +
      escapeHTML(label) +
      "</button>"
    );
  }

  function formField(name, label, controlHTML, error) {
    return (
      '<div class="form-field' +
      (error ? " has-error" : "") +
      '">' +
      '<label class="field-label" for="field-' +
      name +
      '">' +
      escapeHTML(label) +
      "</label>" +
      controlHTML +
      (error
        ? '<p class="field-error" role="alert">' + escapeHTML(error) + "</p>"
        : "") +
      "</div>"
    );
  }

  // -------------------------------------------------------------------
  // INSTRUCTIONS
  // -------------------------------------------------------------------
  function renderInstructions() {
    const userType = State.get().userType;
    const bodyKeyMap = {
      parent: "instructions.parent.body",
      specialist: "instructions.specialist.body",
      audio_parent: "instructions.audio.body"
    };

    const isAudio = userType === "audio_parent";
    const audioButton = isAudio
      ? '<button type="button" class="btn btn-secondary" id="btn-play-instructions">🔊 ' +
        escapeHTML(t("instructions.playAudio")) +
        "</button>"
      : "";

    setHTML(
      '<section class="screen screen-instructions">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("instructions.title")) +
        "</h1>" +
        '<p class="instructions-body">' +
        escapeHTML(t(bodyKeyMap[userType] || "instructions.parent.body")) +
        "</p>" +
        audioButton +
        renderFooterNav({ nextLabel: t("instructions.begin") }) +
        "</section>"
    );

    if (isAudio) {
      document
        .getElementById("btn-play-instructions")
        .addEventListener("click", function () {
          const lang = Language.getCurrentLanguage();
          const path = window.AudioParentQuestions.instructions.start[lang];
          AppAudio.play(path, t(bodyKeyMap[userType]), lang);
        });
    }

    attachFooterNav({
      onNext: function () {
        State.setCurrentQuestionIndex(0);
        return true;
      },
      onBack: function () {
        Navigation.goBack();
      }
    });
  }

  // -------------------------------------------------------------------
  // QUESTIONS
  // -------------------------------------------------------------------
  function renderQuestions() {
    const userType = State.get().userType;
    const total = Questions.getTotalQuestions(userType);
    const index = State.get().currentQuestionIndex;
    const question = Questions.getQuestionByIndex(userType, index);

    if (!question) {
      // Safety net: if something is misconfigured, go back to instructions.
      Navigation.goToScreen("instructions");
      return;
    }

    const progressPercent = Math.round(((index + 1) / total) * 100);
    const chosenAnswerId = State.getAnswer(question.id);
    const isAudioMode = userType === "audio_parent";

    const categoryHTML = question.categoryTitle
      ? '<p class="question-category">' +
        escapeHTML(t("questions.category")) +
        ": " +
        escapeHTML(pick(question.categoryTitle)) +
        "</p>"
      : "";

    const answersHTML = question.answers
      .map(function (answer) {
        const isSelected = chosenAnswerId === answer.id;
        const iconHTML = answer.icon
          ? '<span class="answer-icon" aria-hidden="true">' + answer.icon + "</span>"
          : "";
        return (
          '<button type="button" class="answer-btn' +
          (isSelected ? " selected" : "") +
          (isAudioMode ? " answer-btn-large" : "") +
          '" data-answer-id="' +
          answer.id +
          '">' +
          iconHTML +
          '<span class="answer-label">' +
          escapeHTML(pick(answer.label)) +
          "</span>" +
          "</button>"
        );
      })
      .join("");

    const listenButton = isAudioMode
      ? '<button type="button" class="btn btn-secondary" id="btn-play-question">🔊 ' +
        escapeHTML(t("questions.listenQuestion")) +
        "</button>"
      : "";

    const questionIconHTML = question.icon
      ? '<div class="question-icon" aria-hidden="true">' + question.icon + "</div>"
      : "";

    setHTML(
      '<section class="screen screen-questions">' +
        '<p class="question-counter">' +
        escapeHTML(t("questions.questionOf", { current: index + 1, total: total })) +
        "</p>" +
        '<div class="progress-track" role="progressbar" aria-valuenow="' +
        progressPercent +
        '" aria-valuemin="0" aria-valuemax="100">' +
        '<div class="progress-fill" style="width:' +
        progressPercent +
        '%"></div>' +
        "</div>" +
        categoryHTML +
        questionIconHTML +
        '<h1 class="question-text">' +
        escapeHTML(pick(question.text)) +
        "</h1>" +
        listenButton +
        '<div class="answers-list">' +
        answersHTML +
        "</div>" +
        '<p class="answer-hint">' +
        escapeHTML(t("questions.selectAnswerHint")) +
        "</p>" +
        renderFooterNav({ nextDisabled: !chosenAnswerId }) +
        "</section>"
    );

    screenContainer.querySelectorAll(".answer-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        State.setAnswer(question.id, btn.getAttribute("data-answer-id"));
        renderQuestions();
      });
    });

    if (isAudioMode) {
      document
        .getElementById("btn-play-question")
        .addEventListener("click", function () {
          const lang = Language.getCurrentLanguage();
          const path = question.audio ? question.audio[lang] : null;
          AppAudio.play(path, pick(question.text), lang);
        });
    }

    attachFooterNav({
      onNext: function () {
        if (!State.getAnswer(question.id)) return false;
        if (index < total - 1) {
          State.setCurrentQuestionIndex(index + 1);
          renderQuestions();
          return false; // handled manually, stay on "questions" screen
        }
        return true; // last question -> Navigation moves on to review
      },
      onBack: function () {
        if (index > 0) {
          State.setCurrentQuestionIndex(index - 1);
          renderQuestions();
        } else {
          Navigation.goBack();
        }
      }
    });
  }

  // -------------------------------------------------------------------
  // REVIEW
  // -------------------------------------------------------------------
  function renderReview() {
    const state = State.get();
    const userType = state.userType;
    const flatQuestions = Questions.getFlatQuestions(userType);
    const answeredCount = state.getAnsweredCount
      ? state.getAnsweredCount()
      : Object.keys(state.answers).length;

    const genderLabel =
      state.personInfo.gender === "male"
        ? t("personInfo.genderMale")
        : state.personInfo.gender === "female"
        ? t("personInfo.genderFemale")
        : "";

    const userTypeLabelKeyMap = {
      parent: "userType.parent.title",
      specialist: "userType.specialist.title",
      audio_parent: "userType.audio.title"
    };

    const answersSummaryHTML = flatQuestions
      .map(function (question) {
        const chosenId = State.getAnswer(question.id);
        const chosenAnswer = question.answers.find(function (a) {
          return a.id === chosenId;
        });
        return (
          '<li class="review-answer-row">' +
          '<span class="review-answer-question">' +
          escapeHTML(pick(question.text)) +
          "</span>" +
          '<span class="review-answer-value">' +
          escapeHTML(chosenAnswer ? pick(chosenAnswer.label) : "—") +
          "</span>" +
          "</li>"
        );
      })
      .join("");

    setHTML(
      '<section class="screen screen-review">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("review.title")) +
        "</h1>" +
        '<p class="screen-subtitle">' +
        escapeHTML(t("review.subtitle")) +
        "</p>" +
        '<div class="review-card">' +
        '<h2 class="review-section-title">' +
        escapeHTML(t("review.personSection")) +
        "</h2>" +
        reviewRow(t("review.name"), state.personInfo.name) +
        reviewRow(t("review.age"), state.personInfo.age) +
        reviewRow(t("review.gender"), genderLabel) +
        reviewRow(t("review.userType"), t(userTypeLabelKeyMap[userType])) +
        "</div>" +
        '<div class="review-card">' +
        '<h2 class="review-section-title">' +
        escapeHTML(t("review.answersSection")) +
        "</h2>" +
        '<p class="review-answered-count">' +
        escapeHTML(
          t("review.answeredCount", {
            answered: answeredCount,
            total: flatQuestions.length
          })
        ) +
        "</p>" +
        '<ul class="review-answers-list">' +
        answersSummaryHTML +
        "</ul>" +
        '<button type="button" class="btn btn-ghost" id="btn-edit-answers">' +
        escapeHTML(t("review.editAnswers")) +
        "</button>" +
        "</div>" +
        '<div class="footer-nav">' +
        '<button type="button" class="btn btn-secondary" id="btn-review-back">' +
        escapeHTML(t("common.back")) +
        "</button>" +
        '<button type="button" class="btn btn-primary" id="btn-review-submit">' +
        escapeHTML(t("review.submit")) +
        "</button>" +
        "</div>" +
        "</section>"
    );

    document.getElementById("btn-edit-answers").addEventListener("click", function () {
      State.setCurrentQuestionIndex(0);
      Navigation.goToScreen("questions");
    });

    document.getElementById("btn-review-back").addEventListener("click", function () {
      State.setCurrentQuestionIndex(Math.max(flatQuestions.length - 1, 0));
      Navigation.goToScreen("questions");
    });

    document.getElementById("btn-review-submit").addEventListener("click", function () {
      const score = Scoring.computeScore(state.answers, flatQuestions);
      const resultKey = Scoring.determineResultKey(score);
      State.setScoreResult(score, resultKey);

      const recordId = Storage.saveRecord({
        name: state.personInfo.name,
        age: state.personInfo.age,
        gender: state.personInfo.gender,
        notes: state.personInfo.notes,
        date: state.personInfo.date,
        userType: userType,
        answers: state.answers,
        score: score,
        resultKey: resultKey
      });
      State.setSavedRecordId(recordId);

      Navigation.goToScreen("result");
    });
  }

  function reviewRow(label, value) {
    return (
      '<div class="review-row">' +
      '<span class="review-row-label">' +
      escapeHTML(label) +
      "</span>" +
      '<span class="review-row-value">' +
      escapeHTML(value) +
      "</span>" +
      "</div>"
    );
  }

  // -------------------------------------------------------------------
  // RESULT
  // -------------------------------------------------------------------
  function renderResult() {
    const state = State.get();
    const userTypeLabelKeyMap = {
      parent: "userType.parent.title",
      specialist: "userType.specialist.title",
      audio_parent: "userType.audio.title"
    };
    const message = Scoring.getResultMessage(state.resultKey);
    const genderLabel =
      state.personInfo.gender === "male"
        ? t("personInfo.genderMale")
        : state.personInfo.gender === "female"
        ? t("personInfo.genderFemale")
        : "";

    setHTML(
      '<section class="screen screen-result">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("result.title")) +
        "</h1>" +
        '<div class="review-card">' +
        reviewRow(t("result.name"), state.personInfo.name) +
        reviewRow(t("result.age"), state.personInfo.age) +
        reviewRow(t("result.gender"), genderLabel) +
        reviewRow(t("result.assessmentType"), t(userTypeLabelKeyMap[state.userType])) +
        reviewRow(t("result.score"), state.score) +
        "</div>" +
        '<div class="result-category-card result-' +
        state.resultKey +
        '">' +
        '<h2 class="result-category-title">' +
        escapeHTML(pick(message.title)) +
        "</h2>" +
        '<p class="result-category-description">' +
        escapeHTML(pick(message.description)) +
        "</p>" +
        "</div>" +
        '<div class="disclaimer-box">' +
        '<h3 class="disclaimer-title">⚠ ' +
        escapeHTML(t("result.disclaimerTitle")) +
        "</h3>" +
        '<p class="disclaimer-text">' +
        escapeHTML(t("result.disclaimer")) +
        "</p>" +
        "</div>" +
        '<div class="footer-nav footer-nav-single">' +
        '<button type="button" class="btn btn-primary btn-large" id="btn-result-continue">' +
        escapeHTML(t("result.goToSuccess")) +
        "</button>" +
        "</div>" +
        "</section>"
    );

    document
      .getElementById("btn-result-continue")
      .addEventListener("click", function () {
        Navigation.goToScreen("success");
      });
  }

  // -------------------------------------------------------------------
  // SUCCESS
  // -------------------------------------------------------------------
  function renderSuccess() {
    setHTML(
      '<section class="screen screen-success">' +
        '<div class="success-card">' +
        '<div class="success-icon" aria-hidden="true">' +
        escapeHTML(t("success.icon")) +
        "</div>" +
        '<h1 class="success-title">' +
        escapeHTML(t("success.title")) +
        "</h1>" +
        '<p class="success-message">' +
        escapeHTML(t("success.message")) +
        "</p>" +
        '<div class="welcome-actions">' +
        '<button type="button" class="btn btn-secondary" id="btn-return-home">' +
        escapeHTML(t("success.returnHome")) +
        "</button>" +
        '<button type="button" class="btn btn-primary" id="btn-new-assessment">' +
        escapeHTML(t("success.newAssessment")) +
        "</button>" +
        "</div>" +
        "</div>" +
        "</section>"
    );

    document.getElementById("btn-return-home").addEventListener("click", function () {
      State.reset();
      Navigation.reset();
    });

    document
      .getElementById("btn-new-assessment")
      .addEventListener("click", function () {
        State.reset();
        Navigation.goToScreen("userType");
      });
  }

  // -------------------------------------------------------------------
  // RECORDS (accessed from Welcome, not part of the main step flow)
  // -------------------------------------------------------------------
  function renderRecords(searchQuery) {
    const records = Storage.searchRecordsByName(searchQuery || "");

    const rowsHTML =
      records.length === 0
        ? '<p class="records-empty">' + escapeHTML(t("records.empty")) + "</p>"
        : '<ul class="records-list">' +
          records
            .map(function (record) {
              return (
                '<li class="record-row" data-id="' +
                record.id +
                '">' +
                '<div class="record-main">' +
                '<span class="record-name">' +
                escapeHTML(record.name) +
                "</span>" +
                '<span class="record-date">' +
                escapeHTML((record.date || "").toString()) +
                "</span>" +
                "</div>" +
                '<div class="record-actions">' +
                '<button type="button" class="btn btn-ghost btn-small btn-view-record" data-id="' +
                record.id +
                '">' +
                escapeHTML(t("records.view")) +
                "</button>" +
                '<button type="button" class="btn btn-danger btn-small btn-delete-record" data-id="' +
                record.id +
                '">' +
                escapeHTML(t("records.delete")) +
                "</button>" +
                "</div>" +
                "</li>"
              );
            })
            .join("") +
          "</ul>";

    setHTML(
      '<section class="screen screen-records">' +
        '<h1 class="screen-title">' +
        escapeHTML(t("records.title")) +
        "</h1>" +
        '<p class="screen-subtitle">' +
        escapeHTML(t("records.subtitle")) +
        "</p>" +
        '<input type="search" id="records-search" class="text-input" placeholder="' +
        escapeHTML(t("records.search")) +
        '" value="' +
        escapeHTML(searchQuery || "") +
        '" />' +
        '<div id="records-container">' +
        rowsHTML +
        "</div>" +
        '<div id="record-detail"></div>' +
        '<div class="footer-nav footer-nav-single">' +
        '<button type="button" class="btn btn-secondary" id="btn-records-back">' +
        escapeHTML(t("records.back")) +
        "</button>" +
        "</div>" +
        "</section>"
    );

    document.getElementById("records-search").addEventListener("input", function (e) {
      renderRecords(e.target.value);
    });

    document.getElementById("btn-records-back").addEventListener("click", function () {
      renderScreen(Navigation.getCurrentScreen());
    });

    screenContainer.querySelectorAll(".btn-view-record").forEach(function (btn) {
      btn.addEventListener("click", function () {
        showRecordDetail(btn.getAttribute("data-id"));
      });
    });

    screenContainer.querySelectorAll(".btn-delete-record").forEach(function (btn) {
      btn.addEventListener("click", function () {
        if (window.confirm(t("records.confirmDelete"))) {
          Storage.deleteRecord(btn.getAttribute("data-id"));
          renderRecords(searchQuery);
        }
      });
    });
  }

  function showRecordDetail(id) {
    const record = Storage.getRecord(id);
    const detailContainer = document.getElementById("record-detail");
    if (!record || !detailContainer) return;

    const userTypeLabelKeyMap = {
      parent: "userType.parent.title",
      specialist: "userType.specialist.title",
      audio_parent: "userType.audio.title"
    };
    const message = Scoring.getResultMessage(record.resultKey);

    detailContainer.innerHTML =
      '<div class="review-card record-detail-card">' +
      reviewRow(t("result.name"), record.name) +
      reviewRow(t("result.age"), record.age) +
      reviewRow(t("result.assessmentType"), t(userTypeLabelKeyMap[record.userType] || "")) +
      reviewRow(t("result.score"), record.score) +
      reviewRow(t("result.category"), pick(message.title)) +
      reviewRow(t("records.date"), record.date) +
      '<button type="button" class="btn btn-ghost" id="btn-close-detail">' +
      escapeHTML(t("records.close")) +
      "</button>" +
      "</div>";

    document.getElementById("btn-close-detail").addEventListener("click", function () {
      detailContainer.innerHTML = "";
    });
  }

  // -------------------------------------------------------------------
  // SHARED FOOTER (Back / Next buttons)
  // -------------------------------------------------------------------
  function renderFooterNav(options) {
    options = options || {};
    const nextLabel = options.nextLabel || t("common.next");
    return (
      '<div class="footer-nav">' +
      '<button type="button" class="btn btn-secondary" id="btn-footer-back">' +
      escapeHTML(t("common.back")) +
      "</button>" +
      '<button type="button" class="btn btn-primary" id="btn-footer-next"' +
      (options.nextDisabled ? " disabled" : "") +
      ">" +
      escapeHTML(nextLabel) +
      "</button>" +
      "</div>"
    );
  }

  /**
   * Wires the shared footer's Back/Next buttons.
   * `onNext` may return false to cancel automatic screen advance (useful
   * when a screen manages its own internal steps, like the questions list).
   */
  function attachFooterNav(handlers) {
    const nextBtn = document.getElementById("btn-footer-next");
    const backBtn = document.getElementById("btn-footer-back");

    if (nextBtn) {
      nextBtn.addEventListener("click", function () {
        const shouldAdvance = handlers.onNext ? handlers.onNext() : true;
        if (shouldAdvance) {
          Navigation.goNext();
        }
      });
    }

    if (backBtn) {
      backBtn.addEventListener("click", function () {
        if (handlers.onBack) {
          handlers.onBack();
        } else {
          Navigation.goBack();
        }
      });
    }
  }

  return {
    renderTopBar: renderTopBar,
    renderScreen: renderScreen,
    renderRecords: renderRecords
  };
})();
