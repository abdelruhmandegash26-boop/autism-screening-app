/**
 * storage.js
 * ---------------------------------------------------------------------------
 * Everything related to saving data on THIS device only, using the browser's
 * localStorage. Nothing in this file ever sends data anywhere else.
 *
 * All keys are prefixed with AppConfig.storagePrefix so this app never
 * collides with data from other websites/apps sharing the same browser.
 *
 * Records are stored as a single JSON array under one key:
 *   <prefix>records  ->  [ {id, name, age, gender, userType, answers,
 *                            score, resultKey, date, createdAt}, ... ]
 * ---------------------------------------------------------------------------
 */

window.Storage = (function () {
  const RECORDS_KEY = window.AppConfig.storagePrefix + "records";

  function isAvailable() {
    try {
      const testKey = "__storage_test__";
      window.localStorage.setItem(testKey, "1");
      window.localStorage.removeItem(testKey);
      return true;
    } catch (e) {
      console.warn("[Storage] localStorage is not available:", e);
      return false;
    }
  }

  function getAllRecords() {
    if (!isAvailable()) return [];
    try {
      const raw = window.localStorage.getItem(RECORDS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("[Storage] Failed to read records:", e);
      return [];
    }
  }

  function saveAllRecords(records) {
    if (!isAvailable()) return false;
    try {
      window.localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
      return true;
    } catch (e) {
      console.error("[Storage] Failed to save records:", e);
      return false;
    }
  }

  /** Saves a new record and returns its generated id. */
  function saveRecord(record) {
    const records = getAllRecords();
    const id = "rec_" + Date.now() + "_" + Math.floor(Math.random() * 1000);

    records.push(
      Object.assign({}, record, {
        id: id,
        createdAt: new Date().toISOString()
      })
    );

    saveAllRecords(records);
    return id;
  }

  function getRecord(id) {
    return getAllRecords().find(function (r) {
      return r.id === id;
    });
  }

  function deleteRecord(id) {
    const records = getAllRecords().filter(function (r) {
      return r.id !== id;
    });
    return saveAllRecords(records);
  }

  function searchRecordsByName(query) {
    const normalized = (query || "").trim().toLowerCase();
    if (!normalized) return getAllRecords();

    return getAllRecords().filter(function (r) {
      return (r.name || "").toLowerCase().indexOf(normalized) !== -1;
    });
  }

  return {
    isAvailable: isAvailable,
    getAllRecords: getAllRecords,
    saveRecord: saveRecord,
    getRecord: getRecord,
    deleteRecord: deleteRecord,
    searchRecordsByName: searchRecordsByName
  };
})();
