/**
 * scoring.js
 * ---------------------------------------------------------------------------
 * Turns the user's answers into a total score and a result category, using
 * only the rules defined in data/scoring_config.js. No numbers or wording
 * are hard-coded here.
 * ---------------------------------------------------------------------------
 */

window.Scoring = (function () {
  /**
   * Computes the total score for the current answers against a flat
   * question list (see Questions.getFlatQuestions).
   */
  function computeScore(answers, flatQuestions) {
    let total = 0;

    flatQuestions.forEach(function (question) {
      const chosenAnswerId = answers[question.id];
      if (!chosenAnswerId) return;

      const answerDefinition = question.answers.find(function (a) {
        return a.id === chosenAnswerId;
      });

      if (answerDefinition) {
        total += answerDefinition.score;
      }
    });

    return total;
  }

  /** Finds which threshold key (e.g. "low"/"moderate"/"high") a score falls into. */
  function determineResultKey(score) {
    const thresholds = window.ScoringConfig.thresholds;

    const match = thresholds.find(function (range) {
      return score >= range.min && score <= range.max;
    });

    return match ? match.key : thresholds[thresholds.length - 1].key;
  }

  function getResultMessage(resultKey) {
    return (
      window.ScoringConfig.resultMessages[resultKey] || {
        title: { ar: "", en: "" },
        description: { ar: "", en: "" }
      }
    );
  }

  return {
    computeScore: computeScore,
    determineResultKey: determineResultKey,
    getResultMessage: getResultMessage
  };
})();
