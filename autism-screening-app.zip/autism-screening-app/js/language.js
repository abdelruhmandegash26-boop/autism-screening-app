/**
 * language.js
 * ---------------------------------------------------------------------------
 * Handles the current interface language, translation lookups, and
 * switching the page direction (RTL for Arabic, LTR for English).
 *
 * All user-facing text should be fetched with Language.t("key") rather than
 * written directly in HTML/JS. The actual strings live in
 * data/translations.js.
 * ---------------------------------------------------------------------------
 */

window.Language = (function () {
  let currentLang = window.AppConfig.defaultLanguage || "ar";

  /**
   * Get a translated string by key for the current language.
   * Supports simple {placeholder} substitution, e.g.:
   *   Language.t("questions.questionOf", { current: 2, total: 10 })
   */
  function t(key, params) {
    const dict = window.Translations[currentLang] || {};
    let text = dict[key];

    if (text === undefined) {
      // Fallback: show the key itself so missing translations are obvious
      // during development instead of silently breaking the layout.
      console.warn("[Language] Missing translation for key:", key);
      return key;
    }

    if (params) {
      Object.keys(params).forEach(function (paramKey) {
        text = text.replace("{" + paramKey + "}", params[paramKey]);
      });
    }

    return text;
  }

  function getCurrentLanguage() {
    return currentLang;
  }

  function setLanguage(lang) {
    if (lang !== "ar" && lang !== "en") {
      console.warn("[Language] Unsupported language:", lang);
      return;
    }
    currentLang = lang;
    applyDocumentDirection();
  }

  function applyDocumentDirection() {
    const dir = t("app.direction");
    document.documentElement.setAttribute("lang", currentLang);
    document.documentElement.setAttribute("dir", dir);
    document.body.classList.toggle("rtl", dir === "rtl");
    document.body.classList.toggle("ltr", dir === "ltr");
  }

  /** Get a bilingual field's text for the current language, e.g. {ar, en}. */
  function pick(bilingualObject) {
    if (!bilingualObject) return "";
    return bilingualObject[currentLang] !== undefined
      ? bilingualObject[currentLang]
      : bilingualObject.ar || bilingualObject.en || "";
  }

  return {
    t: t,
    pick: pick,
    getCurrentLanguage: getCurrentLanguage,
    setLanguage: setLanguage,
    applyDocumentDirection: applyDocumentDirection
  };
})();
