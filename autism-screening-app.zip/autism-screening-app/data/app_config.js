/**
 * app_config.js
 * ---------------------------------------------------------------------------
 * GENERAL APPLICATION SETTINGS.
 *
 * Edit this file to change:
 *   - The application name and short description
 *   - The default language
 *   - The color theme (applied automatically to the whole app)
 *   - The font stack
 *   - The localStorage key prefix
 *
 * You do NOT need to touch any other JavaScript file to change these things.
 * ---------------------------------------------------------------------------
 */

window.AppConfig = {
  // Shown on the welcome screen and browser tab.
  appName: {
    ar: "بداية مبكرة",
    en: "Early Steps"
  },

  shortDescription: {
    ar: "أداة تعليمية للتوعية والفحص الأولي لمؤشرات طيف التوحد",
    en: "An educational tool for autism awareness and preliminary screening"
  },

  // Shown in small print near the logo / footer.
  version: "1.0.0 (Educational Demo)",

  // The language used the first time the app is opened.
  // Accepted values: "ar" or "en"
  defaultLanguage: "ar",

  // All localStorage keys created by this app start with this prefix,
  // so the app never collides with other sites' data.
  storagePrefix: "early_steps_app_",

  // ---------------------------------------------------------------------
  // THEME COLORS
  // Change any hex value below and the whole app updates automatically.
  // These are applied to CSS variables at startup (see js/app.js).
  // ---------------------------------------------------------------------
  theme: {
    colorBg: "#F6F8F7",
    colorSurface: "#FFFFFF",
    colorPrimary: "#2F6F6B",
    colorPrimaryDark: "#204E4B",
    colorPrimaryLight: "#DCEAE8",
    colorAccent: "#E2A33D",
    colorSecondary: "#6B8F71",
    colorText: "#1F2A2E",
    colorTextMuted: "#5B6B6E",
    colorBorder: "#DCE4E2",
    colorSuccess: "#3F8F63",
    colorWarning: "#C97A2B",
    colorDanger: "#C0392B",
    radiusSmall: "10px",
    radiusMedium: "16px",
    radiusLarge: "24px"
  },

  // ---------------------------------------------------------------------
  // FONTS
  // No internet fonts are used (fully offline). These are font stacks made
  // of fonts already installed on most devices, with good Arabic + Latin
  // coverage. Add your own installed/local font name at the front of the
  // list to override.
  // ---------------------------------------------------------------------
  fonts: {
    primary:
      "'Segoe UI', Tahoma, 'Geeza Pro', 'Noto Naskh Arabic', Arial, sans-serif",
    heading:
      "'Segoe UI Semibold', 'Segoe UI', Tahoma, 'Geeza Pro', Arial, sans-serif"
  },

  // Screen order used by js/navigation.js. You can reorder these if your
  // flow changes, as long as the names match the screen render functions.
  screenOrder: [
    "welcome",
    "userType",
    "personInfo",
    "instructions",
    "questions",
    "review",
    "result",
    "success"
  ],

  // Set to true to show a "Previous Records" button on the welcome screen.
  enableRecordsScreen: true
};
