/**
 * specialist_questions.js
 * ---------------------------------------------------------------------------
 * QUESTION BANK — SPECIALIST MODE
 *
 * These are DEMO/educational questions only, written for a specialist doing
 * structured observation. They are grouped into categories. This is NOT a
 * validated clinical instrument — do not present it as one.
 *
 * -------------------------- HOW TO EDIT --------------------------
 *
 * TO ADD A CATEGORY:
 *   Add a new { id, title: {ar, en} } object to the "categories" array.
 *
 * TO ADD A QUESTION:
 *   Copy a question block in "questions", give it a new "id", set its
 *   "categoryId" to match one of the categories above, edit the text and
 *   (optionally) the answers.
 *
 * TO CHANGE THE ANSWER SCALE FOR ALL QUESTIONS:
 *   Edit "defaultAnswers" below. Individual questions can still override it
 *   with their own "answers" array.
 * ---------------------------------------------------------------------------
 */

window.SpecialistQuestions = {
  id: "specialist",
  title: {
    ar: "استبيان الأخصائي",
    en: "Specialist Questionnaire"
  },

  categories: [
    { id: "social", title: { ar: "التفاعل الاجتماعي", en: "Social Interaction" } },
    { id: "verbal", title: { ar: "التواصل اللفظي", en: "Verbal Communication" } },
    { id: "nonverbal", title: { ar: "التواصل غير اللفظي", en: "Non-verbal Communication" } },
    { id: "repetitive", title: { ar: "السلوكيات التكرارية", en: "Repetitive Behaviors" } },
    { id: "sensory", title: { ar: "السلوكيات الحسية", en: "Sensory Behaviors" } }
  ],

  // Scale: 0 = typical / not observed, 1 = mild / occasional, 2 = marked / frequent
  defaultAnswers: [
    { id: "not_observed", label: { ar: "غير ملاحظ", en: "Not Observed" }, score: 0 },
    { id: "mild", label: { ar: "طفيف / أحيانًا", en: "Mild / Occasional" }, score: 1 },
    { id: "marked", label: { ar: "واضح / متكرر", en: "Marked / Frequent" }, score: 2 }
  ],

  questions: [
    {
      id: "s1",
      categoryId: "social",
      text: {
        ar: "صعوبة في المبادرة بالتفاعل الاجتماعي مع الأقران.",
        en: "Difficulty initiating social interaction with peers."
      }
    },
    {
      id: "s2",
      categoryId: "social",
      text: {
        ar: "محدودية في المشاركة الاجتماعية أو الانفعالية المتبادلة.",
        en: "Limited social-emotional reciprocity."
      }
    },
    {
      id: "s3",
      categoryId: "social",
      text: {
        ar: "صعوبة في تكوين علاقات ملائمة لمستوى النمو مع الأقران.",
        en: "Difficulty developing peer relationships appropriate to developmental level."
      }
    },
    {
      id: "s4",
      categoryId: "verbal",
      text: {
        ar: "تأخر أو غياب في تطور اللغة المنطوقة دون محاولة تعويض بوسائل بديلة.",
        en: "Delay or absence of spoken language without attempt to compensate through alternative means."
      }
    },
    {
      id: "s5",
      categoryId: "verbal",
      text: {
        ar: "صعوبة في بدء أو استمرار حوار مع الآخرين.",
        en: "Difficulty initiating or sustaining a conversation with others."
      }
    },
    {
      id: "s6",
      categoryId: "verbal",
      text: {
        ar: "استخدام لغة نمطية أو متكررة (ترديد كلامي).",
        en: "Use of stereotyped or repetitive language (echolalia)."
      }
    },
    {
      id: "s7",
      categoryId: "nonverbal",
      text: {
        ar: "ضعف في استخدام سلوكيات غير لفظية متعددة (تواصل بصري، تعبيرات وجه، إيماءات).",
        en: "Impairment in the use of multiple non-verbal behaviors (eye contact, facial expression, gestures)."
      }
    },
    {
      id: "s8",
      categoryId: "nonverbal",
      text: {
        ar: "صعوبة في فهم أو استخدام الإيماءات التواصلية (الإشارة، التلويح).",
        en: "Difficulty understanding or using communicative gestures (pointing, waving)."
      }
    },
    {
      id: "s9",
      categoryId: "repetitive",
      text: {
        ar: "حركات جسدية نمطية متكررة (رفرفة اليدين، الدوران، التمايل).",
        en: "Stereotyped, repetitive motor movements (hand-flapping, spinning, rocking)."
      }
    },
    {
      id: "s10",
      categoryId: "repetitive",
      text: {
        ar: "إصرار على الروتين وصعوبة شديدة في التكيف مع التغيير.",
        en: "Insistence on sameness and marked difficulty adapting to change."
      }
    },
    {
      id: "s11",
      categoryId: "repetitive",
      text: {
        ar: "اهتمامات محدودة وشديدة التركيز بشكل غير معتاد في شدتها.",
        en: "Highly restricted, fixated interests that are unusual in intensity."
      }
    },
    {
      id: "s12",
      categoryId: "sensory",
      text: {
        ar: "استجابة مفرطة أو منخفضة تجاه مؤثرات حسية (صوت، ضوء، ملمس، حرارة).",
        en: "Hyper- or hypo-reactivity to sensory input (sound, light, texture, temperature)."
      }
    },
    {
      id: "s13",
      categoryId: "sensory",
      text: {
        ar: "اهتمام حسي غير معتاد بجوانب معينة من البيئة (شم الأشياء، تفحص الأضواء).",
        en: "Unusual sensory interest in aspects of the environment (smelling objects, fascination with lights)."
      }
    }
  ]
};
