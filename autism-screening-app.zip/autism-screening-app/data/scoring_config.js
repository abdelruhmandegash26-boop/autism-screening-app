/**
 * scoring_config.js
 * ---------------------------------------------------------------------------
 * SCORING RULES AND RESULT MESSAGES.
 *
 * The total score is the sum of every chosen answer's "score" value
 * (see parent_questions.js / specialist_questions.js / audio_parent_questions.js).
 *
 * "thresholds" decides which result category a total score falls into.
 * Each threshold needs: min, max (inclusive), and a "key" that must match
 * one entry in "resultMessages" below.
 *
 * TO CHANGE THE NUMBER RANGES:
 *   Just edit the min/max numbers. Ranges should not overlap and should
 *   cover every possible score from 0 upward (the last max can be a very
 *   large number, e.g. 9999, to catch every higher score).
 *
 * TO CHANGE THE WORDING OF A RESULT:
 *   Edit the matching object inside "resultMessages".
 *
 * IMPORTANT: Keep the wording safe and non-diagnostic (e.g. "may benefit
 * from further observation"), never a diagnosis statement.
 * ---------------------------------------------------------------------------
 */

window.ScoringConfig = {
  thresholds: [
    { min: 0, max: 5, key: "low" },
    { min: 6, max: 10, key: "moderate" },
    { min: 11, max: 9999, key: "high" }
  ],

  resultMessages: {
    low: {
      title: {
        ar: "مؤشر منخفض",
        en: "Low Indication"
      },
      description: {
        ar: "لم تُلاحظ مؤشرات ملفتة بشكل كبير في الإجابات الحالية. يُنصح بالاستمرار في المتابعة الاعتيادية لنمو الطفل.",
        en: "The current answers do not show strongly notable indications. Continued routine developmental follow-up is recommended."
      }
    },
    moderate: {
      title: {
        ar: "يحتاج إلى متابعة إضافية",
        en: "Needs Further Observation"
      },
      description: {
        ar: "أظهرت بعض الإجابات مؤشرات تستدعي المزيد من الملاحظة. قد يكون من المفيد مناقشة هذه الملاحظات مع مختص.",
        en: "Some answers show indications worth watching more closely. It may help to discuss these observations with a professional."
      }
    },
    high: {
      title: {
        ar: "يُنصح باستشارة أخصائي",
        en: "Specialist Consultation Recommended"
      },
      description: {
        ar: "تشير الإجابات إلى عدد من المؤشرات التي يُفضّل مراجعتها مع أخصائي أو مختص نمو الطفل لتقييم أدق.",
        en: "The answers point to a number of indications that are best reviewed with a specialist or child development professional for a more accurate assessment."
      }
    }
  }
};
