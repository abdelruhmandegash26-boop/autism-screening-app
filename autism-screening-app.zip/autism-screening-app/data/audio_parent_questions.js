/**
 * audio_parent_questions.js
 * ---------------------------------------------------------------------------
 * QUESTION BANK — AUDIO-ASSISTED PARENT MODE
 *
 * Designed for a parent who finds reading difficult. Large icons, minimal
 * text, and every question/instruction has a local audio file path.
 *
 * -------------------------- HOW TO EDIT --------------------------
 *
 * TO REPLACE AN AUDIO FILE:
 *   1. Put your new .mp3 file in assets/audio/ar/ (Arabic) or
 *      assets/audio/en/ (English) using the SAME file name referenced below,
 *      OR
 *   2. Change the path string below to point to your new file name.
 *   No JavaScript logic needs to change — only this data file.
 *
 * TO ADD A NEW QUESTION:
 *   Copy a question block, give it a new id, update text/icon/audio paths
 *   and answers.
 *
 * If an audio file is missing, the app automatically falls back to the
 * browser's built-in speech synthesis (still 100% offline, no server calls).
 * ---------------------------------------------------------------------------
 */

window.AudioParentQuestions = {
  id: "audio_parent",
  title: {
    ar: "استبيان صوتي لولي الأمر",
    en: "Audio Questionnaire for Parents"
  },

  instructions: {
    start: {
      ar: "assets/audio/ar/instruction_start.mp3",
      en: "assets/audio/en/instruction_start.mp3"
    },
    next: {
      ar: "assets/audio/ar/instruction_next.mp3",
      en: "assets/audio/en/instruction_next.mp3"
    },
    chooseAnswer: {
      ar: "assets/audio/ar/instruction_choose_answer.mp3",
      en: "assets/audio/en/instruction_choose_answer.mp3"
    }
  },

  // Large-button answer set with icons for quick visual recognition.
  defaultAnswers: [
    { id: "yes", label: { ar: "نعم", en: "Yes" }, icon: "👍", score: 0 },
    { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, icon: "🤔", score: 1 },
    { id: "no", label: { ar: "لا", en: "No" }, icon: "👎", score: 2 }
  ],

  questions: [
    {
      id: "a1",
      icon: "👂",
      text: {
        ar: "هل يستجيب طفلك عند مناداته باسمه؟",
        en: "Does your child respond when called by name?"
      },
      audio: {
        ar: "assets/audio/ar/question_01.mp3",
        en: "assets/audio/en/question_01.mp3"
      }
    },
    {
      id: "a2",
      icon: "👀",
      text: {
        ar: "هل ينظر طفلك في عينيك أثناء الحديث؟",
        en: "Does your child look into your eyes while talking?"
      },
      audio: {
        ar: "assets/audio/ar/question_02.mp3",
        en: "assets/audio/en/question_02.mp3"
      }
    },
    {
      id: "a3",
      icon: "👉",
      text: {
        ar: "هل يشير طفلك بإصبعه ليريك شيئًا؟",
        en: "Does your child point to show you something?"
      },
      audio: {
        ar: "assets/audio/ar/question_03.mp3",
        en: "assets/audio/en/question_03.mp3"
      }
    },
    {
      id: "a4",
      icon: "😊",
      text: {
        ar: "هل يبتسم طفلك عندما تبتسم له؟",
        en: "Does your child smile back when you smile at them?"
      },
      audio: {
        ar: "assets/audio/ar/question_04.mp3",
        en: "assets/audio/en/question_04.mp3"
      }
    },
    {
      id: "a5",
      icon: "🧸",
      text: {
        ar: "هل يحب طفلك اللعب مع أطفال آخرين؟",
        en: "Does your child enjoy playing with other children?"
      },
      audio: {
        ar: "assets/audio/ar/question_05.mp3",
        en: "assets/audio/en/question_05.mp3"
      }
    },
    {
      id: "a6",
      icon: "🗣️",
      text: {
        ar: "هل يتحدث طفلك بكلمات واضحة مناسبة لعمره؟",
        en: "Does your child speak clear words for their age?"
      },
      audio: {
        ar: "assets/audio/ar/question_06.mp3",
        en: "assets/audio/en/question_06.mp3"
      }
    },
    {
      id: "a7",
      icon: "🔁",
      text: {
        ar: "هل يقوم طفلك بحركات متكررة مثل تحريك يديه بسرعة؟",
        en: "Does your child make repeated movements like flapping hands?"
      },
      audio: {
        ar: "assets/audio/ar/question_07.mp3",
        en: "assets/audio/en/question_07.mp3"
      },
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, icon: "👎", score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, icon: "🤔", score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, icon: "👍", score: 2 }
      ]
    },
    {
      id: "a8",
      icon: "🔊",
      text: {
        ar: "هل ينزعج طفلك بشدة من أصوات معينة؟",
        en: "Does your child get very upset by certain sounds?"
      },
      audio: {
        ar: "assets/audio/ar/question_08.mp3",
        en: "assets/audio/en/question_08.mp3"
      },
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, icon: "👎", score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, icon: "🤔", score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, icon: "👍", score: 2 }
      ]
    }
  ]
};
