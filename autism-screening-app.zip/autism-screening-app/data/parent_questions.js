/**
 * parent_questions.js
 * ---------------------------------------------------------------------------
 * QUESTION BANK — PARENT / GUARDIAN MODE
 *
 * These are DEMO/educational questions only. They are written in simple,
 * non-medical language for a parent to answer about observable behavior.
 * They are NOT a validated clinical instrument.
 *
 * -------------------------- HOW TO EDIT --------------------------
 *
 * TO ADD A QUESTION:
 *   1. Copy one whole "{ ... }" block inside the "questions" array below.
 *   2. Give it a new unique "id" (e.g. "p16").
 *   3. Change the Arabic text in text.ar and English text in text.en.
 *   4. Keep or edit the "answers" array (label + score for each choice).
 *   5. Save the file.
 *
 * TO DELETE A QUESTION:
 *   Delete its whole "{ ... }" block from the array (remember the comma).
 *
 * TO CHANGE ANSWER CHOICES OR SCORES:
 *   Edit the "answers" array of any question. Each answer needs:
 *     id     -> a short unique code (used internally, not shown to user)
 *     label  -> { ar: "...", en: "..." } text shown on the button
 *     score  -> the number added to the total when this answer is chosen
 *
 * The order of questions in this array is the order they are shown.
 * ---------------------------------------------------------------------------
 */

window.ParentQuestions = {
  id: "parent",
  title: {
    ar: "استبيان ولي الأمر",
    en: "Parent / Guardian Questionnaire"
  },

  // Reusable default answer set (Yes / Sometimes / No). You can also give
  // any single question its own custom "answers" array instead of this one.
  defaultAnswers: [
    { id: "yes", label: { ar: "نعم", en: "Yes" }, score: 0 },
    { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 },
    { id: "no", label: { ar: "لا", en: "No" }, score: 2 }
  ],

  questions: [
    {
      id: "p1",
      text: {
        ar: "هل يستجيب الطفل عند مناداته باسمه؟",
        en: "Does the child respond when called by name?"
      }
    },
    {
      id: "p2",
      text: {
        ar: "هل ينظر الطفل في عينيك أثناء الحديث أو اللعب؟",
        en: "Does the child make eye contact during talk or play?"
      }
    },
    {
      id: "p3",
      text: {
        ar: "هل يشير الطفل بإصبعه لإظهار شيء يهمه؟",
        en: "Does the child point to show you something interesting?"
      }
    },
    {
      id: "p4",
      text: {
        ar: "هل يشارك الطفل الآخرين في اللعب التخيلي (مثل تمثيل أدوار)؟",
        en: "Does the child engage in pretend/imaginative play with others?"
      }
    },
    {
      id: "p5",
      text: {
        ar: "هل يهتم الطفل باللعب مع أطفال في نفس عمره؟",
        en: "Is the child interested in playing with children of the same age?"
      }
    },
    {
      id: "p6",
      text: {
        ar: "هل يستخدم الطفل كلمات أو جملًا مناسبة لعمره؟",
        en: "Does the child use words or sentences appropriate for their age?"
      }
    },
    {
      id: "p7",
      text: {
        ar: "هل يكرر الطفل كلمات أو عبارات سمعها دون غرض واضح؟",
        en: "Does the child repeat words or phrases without a clear purpose?"
      },
      // Example of a question where the "expected concerning" answer is
      // reversed — scoring is fully independent per answer, so this works
      // without any special-case code.
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, score: 2 }
      ]
    },
    {
      id: "p8",
      text: {
        ar: "هل ينزعج الطفل بشدة من تغييرات بسيطة في روتينه اليومي؟",
        en: "Does the child get very upset by small changes in daily routine?"
      },
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, score: 2 }
      ]
    },
    {
      id: "p9",
      text: {
        ar: "هل يقوم الطفل بحركات متكررة مثل رفرفة اليدين أو التمايل؟",
        en: "Does the child show repetitive movements such as hand-flapping or rocking?"
      },
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, score: 2 }
      ]
    },
    {
      id: "p10",
      text: {
        ar: "هل لدى الطفل حساسية غير معتادة تجاه أصوات أو أضواء أو ملمس معين؟",
        en: "Does the child have unusual sensitivity to certain sounds, lights, or textures?"
      },
      answers: [
        { id: "no", label: { ar: "لا", en: "No" }, score: 0 },
        { id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 },
        { id: "yes", label: { ar: "نعم", en: "Yes" }, score: 2 }
      ]
    },
    {
      id: "p11",
      text: {
        ar: "هل يبتسم الطفل استجابة لابتسامتك؟",
        en: "Does the child smile back in response to your smile?"
      }
    },
    {
      id: "p12",
      text: {
        ar: "هل يحاول الطفل مشاركتك اهتماماته (مثل إحضار لعبة ليريك إياها)؟",
        en: "Does the child try to share interests with you (e.g. bringing a toy to show you)?"
      }
    }
  ]
};
