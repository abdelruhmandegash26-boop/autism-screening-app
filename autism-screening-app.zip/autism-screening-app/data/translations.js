/**
 * translations.js
 * ---------------------------------------------------------------------------
 * ALL INTERFACE TEXT LIVES HERE (Arabic + English).
 *
 * Nothing outside this file (and the question/data files) should contain
 * user-visible sentences. If you want to change any label, button, message,
 * or the medical disclaimer, change it here.
 *
 * Structure:
 *   window.Translations = {
 *     ar: { "section.key": "النص بالعربية", ... },
 *     en: { "section.key": "Text in English", ... }
 *   }
 *
 * To add a brand-new string:
 *   1. Add a key to BOTH the "ar" and "en" objects (same key name).
 *   2. Use it in the code with:  Language.t("section.key")
 * ---------------------------------------------------------------------------
 */

window.Translations = {
  ar: {
    "app.direction": "rtl",
    "app.langLabel": "العربية",
    "app.disclaimerShort":
      "هذه الأداة تعليمية للفحص الأولي فقط، ولا تُعد تشخيصًا طبيًا.",

    // Welcome screen
    "welcome.title": "بداية مبكرة",
    "welcome.subtitle": "أداة تعليمية للتوعية والفحص الأولي لمؤشرات طيف التوحد",
    "welcome.chooseLanguage": "اختر اللغة",
    "welcome.start": "ابدأ الآن",
    "welcome.viewRecords": "السجلات المحفوظة",
    "welcome.demoNotice":
      "نسخة تعليمية توضيحية لعرض جامعي — الأسئلة والدرجات مثال توضيحي وليست أداة سريرية معتمدة.",

    // User type selection
    "userType.title": "من الذي سيجيب على الأسئلة؟",
    "userType.subtitle": "اختر الفئة الأنسب لمتابعة التقييم",
    "userType.parent.title": "ولي الأمر",
    "userType.parent.subtitle": "Parent / Guardian",
    "userType.parent.description": "أسئلة بسيطة وسهلة الفهم لولي الأمر",
    "userType.specialist.title": "الأخصائي",
    "userType.specialist.subtitle": "Specialist",
    "userType.specialist.description":
      "أسئلة مهنية منظمة ضمن محاور تقييم متخصصة",
    "userType.audio.title": "ولي أمر (بمساعدة صوتية)",
    "userType.audio.subtitle": "Audio-Assisted Parent",
    "userType.audio.description":
      "واجهة مبسطة بأزرار كبيرة وأسئلة صوتية لمن يجد صعوبة في القراءة",
    "userType.select": "اختيار",
    "userType.selected": "تم الاختيار",

    // Person info screen
    "personInfo.title": "بيانات الطفل / الشخص",
    "personInfo.subtitle": "يرجى إدخال البيانات التالية قبل المتابعة",
    "personInfo.name": "الاسم",
    "personInfo.namePlaceholder": "اكتب الاسم هنا",
    "personInfo.age": "العمر (بالسنوات)",
    "personInfo.agePlaceholder": "مثال: 4",
    "personInfo.gender": "الجنس",
    "personInfo.genderMale": "ذكر",
    "personInfo.genderFemale": "أنثى",
    "personInfo.date": "التاريخ",
    "personInfo.notes": "ملاحظات (اختياري)",
    "personInfo.notesPlaceholder": "أي ملاحظات إضافية...",
    "personInfo.errors.nameRequired": "الاسم مطلوب ولا يمكن أن يكون فارغًا.",
    "personInfo.errors.ageRequired": "يرجى إدخال عمر صحيح.",
    "personInfo.errors.ageInvalid": "العمر يجب أن يكون رقمًا صحيحًا موجبًا.",
    "personInfo.errors.ageNegative": "العمر لا يمكن أن يكون سالبًا.",
    "personInfo.errors.genderRequired": "يرجى اختيار الجنس.",

    // Instructions screen
    "instructions.title": "قبل أن نبدأ",
    "instructions.parent.body":
      "سنطرح عليك مجموعة من الأسئلة البسيطة حول سلوكيات ملحوظة لدى الطفل. أجب بما يعكس الواقع دون قلق، فهذه الأداة للتوعية والفحص الأولي فقط.",
    "instructions.specialist.body":
      "سيتم عرض الأسئلة مقسّمة حسب محاور التقييم المهنية. يرجى الإجابة بناءً على الملاحظة والتقييم المهني.",
    "instructions.audio.body":
      "اضغط على زر الاستماع لسماع كل سؤال، ثم اختر الإجابة المناسبة بالضغط على الزر الكبير.",
    "instructions.begin": "متابعة إلى الأسئلة",
    "instructions.playAudio": "استمع للتعليمات",

    // Questions screen
    "questions.questionOf": "السؤال {current} من {total}",
    "questions.category": "المحور",
    "questions.listenQuestion": "استمع للسؤال",
    "questions.selectAnswerHint": "اختر إجابة واحدة للمتابعة",

    // Review screen
    "review.title": "مراجعة البيانات قبل الإرسال",
    "review.subtitle": "تأكد من صحة البيانات، ويمكنك التعديل قبل الإرسال",
    "review.personSection": "بيانات الشخص",
    "review.name": "الاسم",
    "review.age": "العمر",
    "review.gender": "الجنس",
    "review.userType": "نوع المستخدم",
    "review.answersSection": "ملخص الإجابات",
    "review.answeredCount": "تمت الإجابة على {answered} من {total} سؤالًا",
    "review.editAnswers": "تعديل الإجابات",
    "review.submit": "إنهاء وإرسال التقييم",

    // Result screen
    "result.title": "نتيجة التقييم الأولي",
    "result.name": "الاسم",
    "result.age": "العمر",
    "result.gender": "الجنس",
    "result.assessmentType": "نوع التقييم",
    "result.score": "الدرجة الكلية",
    "result.category": "التصنيف",
    "result.disclaimerTitle": "تنويه هام",
    "result.disclaimer":
      "هذه الأداة تعليمية للفحص الأولي ولا تقدم تشخيصًا طبيًا. يُنصح دائمًا باستشارة أخصائي أو مختص نمو الطفل للحصول على تقييم دقيق.",
    "result.goToSuccess": "متابعة",

    // Success screen
    "success.title": "تم تسجيل البيانات بنجاح",
    "success.icon": "✅",
    "success.message":
      "تم حفظ بيانات التقييم بنجاح على هذا الجهاز فقط، ولم تُرسل إلى أي جهة خارجية.",
    "success.returnHome": "العودة للصفحة الرئيسية",
    "success.newAssessment": "بدء تقييم جديد",

    // Records screen
    "records.title": "السجلات المحفوظة",
    "records.subtitle": "جميع البيانات محفوظة محليًا على هذا الجهاز فقط",
    "records.search": "بحث بالاسم",
    "records.empty": "لا توجد سجلات محفوظة بعد",
    "records.view": "عرض",
    "records.delete": "حذف",
    "records.confirmDelete": "هل تريد حذف هذا السجل؟",
    "records.back": "رجوع",
    "records.date": "التاريخ",
    "records.close": "إغلاق",

    // Common buttons
    "common.next": "التالي",
    "common.back": "السابق",
    "common.cancel": "إلغاء",
    "common.confirm": "تأكيد",
    "common.required": "* حقل مطلوب",

    // Result categories (default demo wording; edit in scoring_config.js too)
    "resultCategory.low.label": "مؤشر منخفض",
    "resultCategory.moderate.label": "يحتاج إلى متابعة إضافية",
    "resultCategory.high.label": "يُنصح باستشارة أخصائي"
  },

  en: {
    "app.direction": "ltr",
    "app.langLabel": "English",
    "app.disclaimerShort":
      "This tool is an educational preliminary screener only and is not a medical diagnosis.",

    // Welcome screen
    "welcome.title": "Early Steps",
    "welcome.subtitle":
      "An educational tool for autism awareness and preliminary screening",
    "welcome.chooseLanguage": "Choose your language",
    "welcome.start": "Get Started",
    "welcome.viewRecords": "Saved Records",
    "welcome.demoNotice":
      "Educational demo built for a college presentation — questions and scoring are illustrative, not a validated clinical instrument.",

    // User type selection
    "userType.title": "Who will answer the questions?",
    "userType.subtitle": "Choose the option that fits best to continue",
    "userType.parent.title": "Parent / Guardian",
    "userType.parent.subtitle": "ولي الأمر",
    "userType.parent.description":
      "Simple, easy-to-understand questions for a parent",
    "userType.specialist.title": "Specialist",
    "userType.specialist.subtitle": "الأخصائي",
    "userType.specialist.description":
      "Professional questions organized into assessment categories",
    "userType.audio.title": "Audio-Assisted Parent",
    "userType.audio.subtitle": "ولي الأمر (بمساعدة صوتية)",
    "userType.audio.description":
      "A simplified interface with large buttons and spoken questions for parents who find reading difficult",
    "userType.select": "Select",
    "userType.selected": "Selected",

    // Person info screen
    "personInfo.title": "Child / Person Information",
    "personInfo.subtitle": "Please enter the following details to continue",
    "personInfo.name": "Name",
    "personInfo.namePlaceholder": "Enter the name",
    "personInfo.age": "Age (years)",
    "personInfo.agePlaceholder": "e.g. 4",
    "personInfo.gender": "Gender",
    "personInfo.genderMale": "Male",
    "personInfo.genderFemale": "Female",
    "personInfo.date": "Date",
    "personInfo.notes": "Notes (optional)",
    "personInfo.notesPlaceholder": "Any additional notes...",
    "personInfo.errors.nameRequired": "Name is required and cannot be empty.",
    "personInfo.errors.ageRequired": "Please enter a valid age.",
    "personInfo.errors.ageInvalid": "Age must be a whole positive number.",
    "personInfo.errors.ageNegative": "Age cannot be negative.",
    "personInfo.errors.genderRequired": "Please select a gender.",

    // Instructions screen
    "instructions.title": "Before We Begin",
    "instructions.parent.body":
      "We will ask a set of simple questions about behaviors you may have noticed in the child. Answer honestly — this tool is for awareness and preliminary screening only.",
    "instructions.specialist.body":
      "Questions are grouped by professional assessment category. Please answer based on observation and professional judgment.",
    "instructions.audio.body":
      "Press the listen button to hear each question, then choose the matching answer by pressing the large button.",
    "instructions.begin": "Continue to Questions",
    "instructions.playAudio": "Listen to Instructions",

    // Questions screen
    "questions.questionOf": "Question {current} of {total}",
    "questions.category": "Category",
    "questions.listenQuestion": "Listen to Question",
    "questions.selectAnswerHint": "Choose one answer to continue",

    // Review screen
    "review.title": "Review Before Submitting",
    "review.subtitle": "Check the details are correct — you can edit before submitting",
    "review.personSection": "Person Details",
    "review.name": "Name",
    "review.age": "Age",
    "review.gender": "Gender",
    "review.userType": "User Type",
    "review.answersSection": "Answers Summary",
    "review.answeredCount": "{answered} of {total} questions answered",
    "review.editAnswers": "Edit Answers",
    "review.submit": "Finish Assessment",

    // Result screen
    "result.title": "Preliminary Assessment Result",
    "result.name": "Name",
    "result.age": "Age",
    "result.gender": "Gender",
    "result.assessmentType": "Assessment Type",
    "result.score": "Total Score",
    "result.category": "Result Category",
    "result.disclaimerTitle": "Important Notice",
    "result.disclaimer":
      "This tool is an educational preliminary screener and does not provide a medical diagnosis. A qualified specialist or child development professional should always be consulted for a proper assessment.",
    "result.goToSuccess": "Continue",

    // Success screen
    "success.title": "Data Registered Successfully",
    "success.icon": "✅",
    "success.message":
      "The assessment data was saved successfully on this device only, and was not sent anywhere.",
    "success.returnHome": "Return Home",
    "success.newAssessment": "Start New Assessment",

    // Records screen
    "records.title": "Saved Records",
    "records.subtitle": "All data is stored locally on this device only",
    "records.search": "Search by name",
    "records.empty": "No saved records yet",
    "records.view": "View",
    "records.delete": "Delete",
    "records.confirmDelete": "Delete this record?",
    "records.back": "Back",
    "records.date": "Date",
    "records.close": "Close",

    // Common buttons
    "common.next": "Next",
    "common.back": "Back",
    "common.cancel": "Cancel",
    "common.confirm": "Confirm",
    "common.required": "* Required field",

    // Result categories (default demo wording; edit in scoring_config.js too)
    "resultCategory.low.label": "Low Indication",
    "resultCategory.moderate.label": "Needs Further Observation",
    "resultCategory.high.label": "Specialist Consultation Recommended"
  }
};
