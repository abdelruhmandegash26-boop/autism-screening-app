# Arabic audio files go here

Put your local `.mp3` files in this folder using the exact names referenced
in `data/audio_parent_questions.js`, for example:

- instruction_start.mp3
- instruction_next.mp3
- instruction_choose_answer.mp3
- question_01.mp3 ... question_08.mp3

No files are included in this demo, so the app will automatically use the
device's built-in speech synthesis (still 100% offline) until you add real
recordings here.
