# Early Steps — Autism Awareness & Preliminary Screening (Educational Demo)

> **Important:** This is an educational college-presentation prototype.
> It is **not** a medical diagnostic tool, and the questions/scoring are
> **not** a validated clinical instrument. It always shows a disclaimer
> recommending that a qualified specialist be consulted.

A fully offline, no-backend, no-internet web app that walks a parent,
specialist, or audio-assisted parent through a short preliminary
questionnaire, in Arabic (RTL) or English (LTR), and stores results only on
the user's own device (localStorage).

---

## 1. Running the app

No installation, no build step, no server required.

**Option A — just open it**
Double-click `index.html` (or right-click → Open With → your browser).

**Option B — local server (optional, e.g. if your browser restricts local
file access for audio playback)**
From inside the project folder:

```bash
# Python 3
python3 -m http.server 8000
# then open http://localhost:8000 in your browser
```

No internet connection is used at any point — every CSS file, JS file, and
icon is loaded from disk.

---

## 2. Project structure

```
autism-screening-app/
│
├── index.html                  ← Entry point, loads everything else locally
│
├── css/
│   ├── style.css                ← Core styles + theme (colors come from data/app_config.js)
│   └── responsive.css           ← Tablet/mobile breakpoints
│
├── js/
│   ├── app.js                   ← Boot sequence (applies theme, starts first screen)
│   ├── language.js               ← Translation lookup + RTL/LTR switching
│   ├── state.js                  ← In-memory session state (answers, person info, etc.)
│   ├── navigation.js             ← Which screen is shown, and in what order
│   ├── render.js                 ← Builds the HTML for every screen
│   ├── validation.js             ← Form + answer validation rules
│   ├── questions.js               ← Picks the right question bank for the user type
│   ├── scoring.js                 ← Turns answers into a score + result category
│   ├── storage.js                 ← Saves/reads/deletes records in localStorage
│   └── audio.js                   ← Plays local audio files (+ speech-synthesis fallback)
│
├── data/                        ← YOU WILL EDIT THIS FOLDER THE MOST
│   ├── app_config.js             ← App name, colors, fonts, screen order
│   ├── translations.js           ← Every Arabic/English UI string
│   ├── parent_questions.js       ← Parent/Guardian question bank
│   ├── specialist_questions.js   ← Specialist question bank (with categories)
│   ├── audio_parent_questions.js ← Audio-assisted parent question bank + audio paths
│   └── scoring_config.js         ← Score thresholds + result messages
│
├── assets/
│   ├── images/logo.svg           ← App logo (local SVG, no external image needed)
│   ├── icons/                    ← Room for any extra local icon files
│   └── audio/
│       ├── ar/                   ← Arabic .mp3 files (see README inside)
│       └── en/                   ← English .mp3 files (see README inside)
│
└── README.md                     ← This file
```

**Rule of thumb:** if you want to change *content* (text, questions,
scores, colors, audio paths), edit a file in `data/`. You should almost
never need to touch the files in `js/`.

---

## 3. How the app works (quick tour)

1. `index.html` loads the `data/*.js` files first (so all content is
   available), then the `js/*.js` logic files, in dependency order.
2. `app.js` reads `data/app_config.js`, applies the colors/fonts as CSS
   variables, and shows the first screen ("welcome").
3. `navigation.js` keeps track of which screen is active, using the order
   defined in `app_config.js -> screenOrder`.
4. `render.js` draws whichever screen is active by reading data from
   `state.js` and text from `language.js` (which reads `translations.js`).
5. When you tap an answer, `state.js` stores it. When you press "Next",
   `validation.js` checks the current screen is valid before allowing you to
   continue.
6. On submit, `scoring.js` computes the total score and result category
   using only the rules in `data/scoring_config.js`, and `storage.js` saves
   the whole record to `localStorage` (this device only).

---

## 4. Editing guide (with examples)

### Change the application name
Open `data/app_config.js` and edit:
```js
appName: {
  ar: "بداية مبكرة",
  en: "Early Steps"
}
```

### Change any Arabic or English interface text
Open `data/translations.js`. Every string has a key, e.g. `"welcome.title"`.
Find the key under `ar: {...}` and/or `en: {...}` and change the text
between the quotes. Keep the key names exactly as they are.

### Add a new Parent question
1. Open `data/parent_questions.js`.
2. Copy an existing question block, e.g.:
   ```js
   {
     id: "p13",
     text: {
       ar: "نص السؤال بالعربية",
       en: "Question text in English"
     }
   }
   ```
3. Give it a unique `id` (no other question should use the same id).
4. Change the Arabic and English text.
5. If you want custom answers/scores instead of the default Yes/Sometimes/No,
   add an `answers` array (see below).
6. Save the file — the question appears automatically, and the progress bar
   and question counter update themselves.

### Delete a question
Delete its whole `{ ... }` block (including the surrounding braces and the
following comma) from the `questions` array in the matching data file.

### Change answer choices or scores
Every answer looks like this:
```js
{ id: "sometimes", label: { ar: "أحيانًا", en: "Sometimes" }, score: 1 }
```
- `id` — internal code, must be unique within that question's answers.
- `label` — what the user sees, in both languages.
- `score` — the number added to the total score if this answer is chosen.

To change a score, just change the number. To change the wording, edit the
`label`. To add a 4th answer choice, add another object to the array.

### Add a new question category (Specialist mode)
Open `data/specialist_questions.js` and add to the `categories` array:
```js
{ id: "new_category", title: { ar: "اسم المحور", en: "Category Name" } }
```
Then set `categoryId: "new_category"` on any question that belongs to it.

### Change result thresholds or messages
Open `data/scoring_config.js`.
- To change the score ranges, edit the `min`/`max` numbers in `thresholds`.
- To change the wording shown for a result, edit the matching entry in
  `resultMessages` (`low`, `moderate`, or `high`).

### Replace or add an audio file
1. Record or obtain your `.mp3` file.
2. Place it in `assets/audio/ar/` (Arabic) or `assets/audio/en/` (English)
   using the same file name referenced in
   `data/audio_parent_questions.js` — for example `question_01.mp3`.
3. That's it — no JavaScript changes needed. If a file is missing, the app
   automatically falls back to the browser's built-in offline text-to-speech.

To point to a different file name instead, edit the path string in
`data/audio_parent_questions.js`, e.g.:
```js
audio: {
  ar: "assets/audio/ar/my_new_file.mp3",
  en: "assets/audio/en/my_new_file.mp3"
}
```

### Change colors
Open `data/app_config.js -> theme`. Every value is a hex color, e.g.:
```js
colorPrimary: "#2F6F6B",
```
Change the hex code and reload the page — every button, card, and accent
using that color updates automatically (no CSS editing needed).

### Change fonts
Open `data/app_config.js -> fonts`. Add the name of a font already
installed on your computer to the front of the list, e.g.:
```js
primary: "'My Installed Font', 'Segoe UI', Tahoma, Arial, sans-serif"
```
No fonts are downloaded from the internet — everything relies on fonts
already available on the device, so the app keeps working fully offline.

### Change icons/images
- The logo is `assets/images/logo.svg` — replace this file with your own
  SVG (or update `index.html`/`render.js` if you rename it).
- Question and answer icons are simple emoji characters set directly in the
  data files (e.g. `icon: "👍"` in `audio_parent_questions.js`). Change the
  emoji/character to any other one you like.

### Change the number of questions
Just add or remove question blocks in the relevant data file — the
progress bar, "Question X of Y" counter, and review screen all calculate
totals automatically.

### Reorder the screens
Open `data/app_config.js -> screenOrder`. Reordering this array changes the
order the app moves through — just make sure the names match what
`js/render.js` knows how to draw (`welcome`, `userType`, `personInfo`,
`instructions`, `questions`, `review`, `result`, `success`).

---

## 5. Where user data is stored

All data (name, age, gender, answers, score, result, date) is saved with
`localStorage` on the visitor's own device only — see `js/storage.js`. No
data is ever sent to a server, because there is no server. Users can view,
search, and delete their previously saved records from the "Saved Records"
link on the welcome screen.

---

## 6. Testing checklist

Use this list before presenting the project:

- [ ] Open `index.html` directly in a browser (no local server)
- [ ] Complete the flow in Arabic (Parent → valid data → all questions →
      review → submit → result → success)
- [ ] Repeat the full flow in English
- [ ] Complete the flow as Specialist
- [ ] Complete the flow as Audio-Assisted Parent, test the listen buttons
- [ ] Try submitting the person-info form with an empty name / negative age
      / no gender selected — confirm clear inline error messages appear
- [ ] Try pressing "Next" on a question with no answer selected — confirm
      it's disabled/blocked
- [ ] Use the Back button at every step, confirm no data is lost
- [ ] Open "Saved Records", search by name, view a record, delete a record
- [ ] Resize the browser down to a phone width and confirm the layout adapts
- [ ] Replace one `.mp3` filename in `data/audio_parent_questions.js` with a
      non-existent file and confirm the speech-synthesis fallback still
      reads the question aloud

---

## 7. No external dependencies

This app uses plain HTML, CSS, and JavaScript only — no frameworks, no
build tools, no CDNs, no online fonts, and no backend/database of any kind.
It will keep working exactly the same with no internet connection.
